"use client"

import { FamilyCoupleProfile } from "@/components/family/family-couple-profile"
import { FamilyBottomNav } from "@/components/family/family-bottom-nav"
import { ArrowLeft, Settings, ChevronRight, Bell, Shield, HelpCircle, LogOut } from "lucide-react"
import Link from "next/link"

export default function FamilyProfilePage() {
  return (
    <main className="min-h-dvh bg-[#F2F4F6] pb-20">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-white border-b border-[#E5E8EB]">
        <div className="flex items-center justify-between px-4 h-14 max-w-md mx-auto">
          <div className="flex items-center gap-3">
            <Link 
              href="/family" 
              className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F2F4F6] transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-[#191F28]" />
            </Link>
            <h1 className="text-[17px] font-bold text-[#191F28]">프로필</h1>
          </div>
          <button className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-[#F2F4F6] transition-colors">
            <Settings className="w-5 h-5 text-[#4E5968]" />
          </button>
        </div>
      </header>

      <div className="px-5 py-5 max-w-md mx-auto space-y-4">
        <FamilyCoupleProfile />
        
        {/* Membership Card */}
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-[20px] p-5 text-white">
          <p className="text-[13px] opacity-80 mb-1">현재 멤버십</p>
          <p className="text-[22px] font-bold mb-4">Family Premium</p>
          <div className="flex justify-between items-end">
            <div>
              <p className="text-[12px] opacity-70">다음 결제일</p>
              <p className="text-[14px] font-medium">2026.03.01</p>
            </div>
            <button className="px-4 py-2 bg-white/20 rounded-[10px] text-[13px] font-medium hover:bg-white/30 transition-colors">
              멤버십 관리
            </button>
          </div>
        </div>

        {/* Settings Menu */}
        <div className="bg-white rounded-[20px] shadow-sm overflow-hidden">
          {[
            { icon: Bell, label: "알림 설정", desc: "푸시 알림 및 앱 알림" },
            { icon: Shield, label: "개인정보 보호", desc: "프라이버시 및 보안 설정" },
            { icon: HelpCircle, label: "고객센터", desc: "문의하기 및 FAQ" },
          ].map((item, idx) => (
            <button
              key={item.label}
              className={`w-full flex items-center gap-4 px-5 py-4 hover:bg-[#F8F9FA] transition-colors ${
                idx !== 2 ? "border-b border-[#F2F4F6]" : ""
              }`}
            >
              <div className="w-10 h-10 rounded-full bg-[#F2F4F6] flex items-center justify-center">
                <item.icon className="w-5 h-5 text-[#4E5968]" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-[15px] font-medium text-[#191F28]">{item.label}</p>
                <p className="text-[13px] text-[#8B95A1]">{item.desc}</p>
              </div>
              <ChevronRight className="w-5 h-5 text-[#B0B8C1]" />
            </button>
          ))}
        </div>

        {/* Logout */}
        <button className="w-full flex items-center justify-center gap-2 py-4 text-[#FF6B6B] text-[15px] font-medium hover:bg-white rounded-[16px] transition-colors">
          <LogOut className="w-5 h-5" />
          로그아웃
        </button>
      </div>

      <FamilyBottomNav />
    </main>
  )
}
